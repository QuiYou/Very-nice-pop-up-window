//
//  CalanderVC.h
//  WMZDialog
//
//  Created by wmz on 2019/11/8.
//  Copyright © 2019 wmz. All rights reserved.
//

#import "BaseVC.h"
NS_ASSUME_NONNULL_BEGIN

@interface MyCalanderCell : UICollectionViewCell
@property (nonatomic,strong) UILabel *dateLable;
@end


@interface CalanderVC : BaseVC

@end

NS_ASSUME_NONNULL_END
