//
//  NewCustomVC.h
//  WMZDialog
//
//  Created by wmz on 2021/9/28.
//  Copyright © 2021 wmz. All rights reserved.
//

#import "BaseVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface NewCustomVC : BaseVC

@end

NS_ASSUME_NONNULL_END
