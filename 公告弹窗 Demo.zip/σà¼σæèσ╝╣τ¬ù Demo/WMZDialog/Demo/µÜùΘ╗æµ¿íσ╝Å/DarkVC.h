//
//  DarkVC.h
//  WMZDialog
//
//  Created by wmz on 2021/9/29.
//  Copyright © 2021 wmz. All rights reserved.
//

#import "BaseVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface DarkVC : BaseVC

@end

NS_ASSUME_NONNULL_END
