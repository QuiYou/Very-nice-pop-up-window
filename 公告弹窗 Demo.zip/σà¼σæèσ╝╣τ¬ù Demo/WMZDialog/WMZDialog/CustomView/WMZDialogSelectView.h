//
//  WMZDialogSelectView.h
//  WMZDialog
//
//  Created by wmz on 2021/7/21.
//  Copyright © 2021 wmz. All rights reserved.
//

#import "WMZDialogTable.h"

NS_ASSUME_NONNULL_BEGIN

@interface WMZDialogSelectView : WMZDialogTable<NSXMLParserDelegate>

@end

NS_ASSUME_NONNULL_END
