//
//  WMZCustomEditView.h
//  WMZDialog
//
//  Created by wmz on 2021/7/26.
//  Copyright © 2021 wmz. All rights reserved.
//

#import "WMZDialogNormal.h"

NS_ASSUME_NONNULL_BEGIN

@interface WMZDialogEditView : WMZDialogNormal

@end

NS_ASSUME_NONNULL_END
