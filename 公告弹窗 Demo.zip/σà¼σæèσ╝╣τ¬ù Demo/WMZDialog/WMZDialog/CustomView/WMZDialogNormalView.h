//
//  WMZDialogNormalView.h
//  WMZDialog
//
//  Created by wmz on 2021/7/17.
//  Copyright © 2021 wmz. All rights reserved.
//

#import "WMZDialogNormal.h"

NS_ASSUME_NONNULL_BEGIN

@interface WMZDialogNormalView : WMZDialogNormal

@end

NS_ASSUME_NONNULL_END
